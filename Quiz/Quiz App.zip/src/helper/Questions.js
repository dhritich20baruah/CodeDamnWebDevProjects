export const Questions = [
    {
        prompt: "What is tailwind css?",
        optionA:"CSS library",
        optionB: "Programing language",
        optionC: "Utility first CSS framework",
        optionD: "CSS scripting language",
        answer: "optionC"
    },
    {
        prompt: "Which one of this is not a programing language?",
        optionA:"C++",
        optionB: "Java",
        optionC: "Javascript",
        optionD: "HTML",
        answer: "optionD"
    },
    {
        prompt: "Which one of this is not a javascript framework?",
        optionA:"React",
        optionB: "Angular",
        optionC: "Vue",
        optionD: "Django",
        answer: "optionD"
    }]